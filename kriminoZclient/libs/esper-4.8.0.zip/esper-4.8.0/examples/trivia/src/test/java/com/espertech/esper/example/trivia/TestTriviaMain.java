package com.espertech.esper.example.trivia;

import junit.framework.TestCase;

public class TestTriviaMain extends TestCase {

    public void testRounds() {
        TriviaMain main = new TriviaMain();
        main.run();
    }
}
