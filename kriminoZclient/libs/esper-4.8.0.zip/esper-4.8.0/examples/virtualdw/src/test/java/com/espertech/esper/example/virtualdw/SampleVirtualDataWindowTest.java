package com.espertech.esper.example.virtualdw;

import junit.framework.TestCase;

/**
 * Test case for Large-External Data Window.
 */
public class SampleVirtualDataWindowTest extends TestCase
{
    public void testSample()
    {
        SampleVirtualDataWindowMain main = new SampleVirtualDataWindowMain();
        main.run();
    }
}
